package com.Duoc.DuocPickuUp.repository;

import com.Duoc.DuocPickuUp.model.DetalleCompra;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalleCompraRepository extends JpaRepository<DetalleCompra, Long> {
}