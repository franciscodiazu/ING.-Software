
-- Usuarios base
INSERT INTO usuario (id, nombre, email, contrasena) VALUES (1, 'Juan Pérez', 'juan@example.com', '1234');
INSERT INTO usuario (id, nombre, email, contrasena) VALUES (2, 'Ana Torres', 'ana@example.com', 'abcd');

-- Estudiantes
INSERT INTO estudiante (id, carrera) VALUES (1, 'Ingeniería en Informática');

-- Administradores
INSERT INTO administrador (id, rol) VALUES (2, 'ADMIN');

-- Locales
INSERT INTO local (id, nombre) VALUES (1, 'Cafetería Central');

-- Categorías de producto
INSERT INTO categoria_producto (id, nombre) VALUES (1, 'Bebidas');
INSERT INTO categoria_producto (id, nombre) VALUES (2, 'Snacks');

-- Estado de producto
INSERT INTO estado_producto (id, nombre) VALUES (1, 'Disponible');
INSERT INTO estado_producto (id, nombre) VALUES (2, 'Agotado');

-- Productos
INSERT INTO producto (id, nombre, precio, local_id, categoria_producto_id, estado_producto_id)
VALUES (1, 'Café Latte', 1500, 1, 1, 1);
INSERT INTO producto (id, nombre, precio, local_id, categoria_producto_id, estado_producto_id)
VALUES (2, 'Galletas', 1000, 1, 2, 1);

-- Pedido
INSERT INTO pedido (id, estado, usuario_id)
VALUES (1, 'Pendiente', 1);

-- Compra
INSERT INTO compra (id, total, pedido_id)
VALUES (1, 2500, 1);

-- Detalles de compra
INSERT INTO detalle_compra (id, producto_id, compra_id, cantidad)
VALUES (1, 1, 1, 1);
INSERT INTO detalle_compra (id, producto_id, compra_id, cantidad)
VALUES (2, 2, 1, 1);

-- Tabla intermedia de productos en pedidos (ManyToMany)
INSERT INTO pedido_productos (pedido_id, productos_id) VALUES (1, 1);
INSERT INTO pedido_productos (pedido_id, productos_id) VALUES (1, 2);
