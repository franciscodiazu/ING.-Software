package com.Duoc.DuocPickuUp.controller;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.Compra;
import com.Duoc.DuocPickuUp.model.Usuario;
import com.Duoc.DuocPickuUp.service.ServicioCarrito;
import com.Duoc.DuocPickuUp.service.ServicioCompra;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/compra")
public class ControladorCompra {

    @Autowired
    private ServicioCompra servicioCompra;

    @Autowired
    private ServicioCarrito servicioCarrito; // Para verificar el carrito antes del checkout

    // Muestra el formulario de checkout
    @GetMapping("/checkout")
    public String mostrarCheckout(Model modelo, HttpSession session, RedirectAttributes redirectAttributes) {
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");

        // Regla: Solo estudiantes logueados pueden acceder al checkout
        if (usuarioLogeado == null || !usuarioLogeado.getRol().equals(Usuario.Rol.ESTUDIANTE)) {
            redirectAttributes.addFlashAttribute("error", "Debes iniciar sesión como estudiante para proceder al pago.");
            return "redirect:/auth/login"; // Redirige al login
        }

        Carrito carritoActual = servicioCarrito.obtenerCarritoActual();
        if (carritoActual == null || carritoActual.getItems().isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Tu carrito está vacío. Agrega productos antes de pagar.");
            return "redirect:/carrito"; // Redirige al carrito si está vacío
        }

        modelo.addAttribute("usuario", usuarioLogeado); // Pasar el usuario logueado para mostrar sus datos
        modelo.addAttribute("carrito", carritoActual); // Pasar el carrito al checkout
        return "checkout";
    }

    // Procesa el pago y crea la compra
    @PostMapping("/procesar")
    public String procesarCompra(
            @RequestParam("tipoTarjeta") String tipoTarjeta,
            @RequestParam("numeroTarjeta") String numeroTarjeta, // No se guarda completo
            @RequestParam("cvv") String cvv, // No se guarda
            @RequestParam("nombreTitular") String nombreTitular,
            @RequestParam("direccionEnvio") String direccionEnvio,
            @RequestParam("ciudadEnvio") String ciudadEnvio,
            @RequestParam("codigoPostalEnvio") String codigoPostalEnvio,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");

        if (usuarioLogeado == null || !usuarioLogeado.getRol().equals(Usuario.Rol.ESTUDIANTE)) {
            redirectAttributes.addFlashAttribute("error", "Debes iniciar sesión como estudiante para realizar una compra.");
            return "redirect:/auth/login";
        }

        try {
            // Validaciones básicas de formulario (puedes añadir más)
            if (numeroTarjeta.length() < 13 || numeroTarjeta.length() > 19 || !numeroTarjeta.matches("\\d+")) {
                redirectAttributes.addFlashAttribute("error", "Número de tarjeta inválido.");
                return "redirect:/compra/checkout";
            }
            if (cvv.length() < 3 || cvv.length() > 4 || !cvv.matches("\\d+")) {
                redirectAttributes.addFlashAttribute("error", "CVV inválido.");
                return "redirect:/compra/checkout";
            }

            // El servicio de compra se encarga de todo el proceso
            Compra compraExitosa = servicioCompra.procesarCompra(
                tipoTarjeta, numeroTarjeta, nombreTitular,
                direccionEnvio, ciudadEnvio, codigoPostalEnvio,
                usuarioLogeado
            );

            redirectAttributes.addFlashAttribute("mensaje", "¡Compra realizada con éxito! Su número de boleta es: " + compraExitosa.getId());
            return "redirect:/compra/boleta/" + compraExitosa.getId(); // Redirige a la boleta
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", "Error al procesar la compra: " + e.getMessage());
            return "redirect:/compra/checkout"; // Vuelve al checkout si hay un error
        }
    }

    // Muestra la boleta de compra
    @GetMapping("/boleta/{id}")
    public String mostrarBoleta(@PathVariable Long id, Model modelo, RedirectAttributes redirectAttributes, HttpSession session) {
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");

        if (usuarioLogeado == null) {
            redirectAttributes.addFlashAttribute("error", "Debes iniciar sesión para ver tus boletas.");
            return "redirect:/auth/login";
        }

        return servicioCompra.obtenerCompraPorId(id)
            .map(compra -> {
                // Asegurarse de que el usuario logueado es el dueño de la compra
                if (!compra.getUsuario().getId().equals(usuarioLogeado.getId())) {
                    redirectAttributes.addFlashAttribute("error", "No tienes permiso para ver esta boleta.");
                    return "redirect:/productos"; // O a una página de error de acceso denegado
                }
                modelo.addAttribute("compra", compra);
                modelo.addAttribute("carrito", servicioCarrito.obtenerCarritoActual()); // Añadir el carrito para el encabezado
                return "boleta"; // Nombre de la plantilla HTML
            })
            .orElseGet(() -> {
                redirectAttributes.addFlashAttribute("error", "Boleta no encontrada.");
                return "redirect:/productos"; // O a la página de inicio
            });
    }
}