package com.Duoc.DuocPickuUp.repository;

import com.Duoc.DuocPickuUp.model.Compra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositorioCompra extends JpaRepository<Compra, Long> {
    // Puedes añadir métodos para buscar compras por usuario, etc.
}