package com.Duoc.DuocPickuUp.service;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.ItemCarrito;
import com.Duoc.DuocPickuUp.model.Producto;
import com.Duoc.DuocPickuUp.model.Usuario;
import com.Duoc.DuocPickuUp.repository.RepositorioCarrito;
import com.Duoc.DuocPickuUp.repository.RepositorioItemCarrito; // Necesario para gestionar ItemCarrito
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class ServicioCarrito {

    @Autowired
    private RepositorioCarrito repositorioCarrito;

    @Autowired
    private RepositorioItemCarrito repositorioItemCarrito; // Para guardar y eliminar items del carrito

    @Autowired
    private ServicioProducto servicioProducto;

    @Autowired
    private HttpSession session; // Para manejar el carrito en la sesión del usuario

    // Método para obtener el carrito actual del usuario o crear uno nuevo
    public Carrito obtenerCarritoActual() {
        // Intentar recuperar el carrito de la sesión
        Long carritoId = (Long) session.getAttribute("carritoId");
        Carrito carrito = null;

        if (carritoId != null) {
            Optional<Carrito> optionalCarrito = repositorioCarrito.findById(carritoId);
            if (optionalCarrito.isPresent() && !optionalCarrito.get().isCompletado()) {
                carrito = optionalCarrito.get();
            }
        }

        // Si no hay carrito en sesión o está completado, crear uno nuevo
        if (carrito == null) {
            carrito = new Carrito();
            carrito.setFechaCreacion(LocalDateTime.now());
            carrito.setCompletado(false);

            // Asociar el carrito al usuario logueado, si existe
            Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");
            if (usuarioLogeado != null) {
                // Si el usuario ya tiene un carrito no completado, usar ese
                Optional<Carrito> existingUserCart = repositorioCarrito.findByUsuarioAndCompletadoFalse(usuarioLogeado);
                if (existingUserCart.isPresent()) {
                    carrito = existingUserCart.get();
                } else {
                    carrito.setUsuario(usuarioLogeado);
                    carrito = repositorioCarrito.save(carrito);
                }
            } else {
                carrito = repositorioCarrito.save(carrito);
            }
            session.setAttribute("carritoId", carrito.getId()); // Guardar el ID en la sesión
        }
        return carrito;
    }

    @Transactional
    public void agregarProductoAlCarrito(Long productoId, int cantidad) {
        Producto producto = servicioProducto.obtenerProductoPorId(productoId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + productoId));

        if (producto.getStock() < cantidad) {
            throw new RuntimeException("No hay suficiente stock para el producto: " + producto.getNombre() + ". Stock disponible: " + producto.getStock());
        }

        Carrito carrito = obtenerCarritoActual(); // Obtiene el carrito actual (de la sesión o crea uno nuevo)
        Optional<ItemCarrito> existingItem = carrito.getItems().stream()
                .filter(item -> item.getProducto().getId().equals(productoId))
                .findFirst();

        if (existingItem.isPresent()) {
            ItemCarrito item = existingItem.get();
            item.setCantidad(item.getCantidad() + cantidad);
            repositorioItemCarrito.save(item); // Guardar el item actualizado
        } else {
            ItemCarrito newItem = new ItemCarrito();
            newItem.setProducto(producto);
            newItem.setCantidad(cantidad);
            newItem.setCarrito(carrito); // Establecer la referencia al carrito
            carrito.getItems().add(newItem); // Añadir el nuevo item a la lista del carrito
            repositorioItemCarrito.save(newItem); // Guardar el nuevo item
        }

        // No es necesario actualizar el stock del producto aquí, se hace en el servicio de compra cuando se procesa la compra.
        // repositorioProducto.save(producto); // Esto se haría si agregaras al carrito y automáticamente se descontara el stock
        repositorioCarrito.save(carrito); // Guardar el carrito para asegurar que los items se persistan si son nuevos
    }

    @Transactional
    public void eliminarProductoDelCarrito(Long itemId) {
        Carrito carrito = obtenerCarritoActual();
        Optional<ItemCarrito> itemToRemove = repositorioItemCarrito.findById(itemId);

        if (itemToRemove.isPresent() && itemToRemove.get().getCarrito().getId().equals(carrito.getId())) {
            repositorioItemCarrito.delete(itemToRemove.get());
            carrito.getItems().remove(itemToRemove.get()); // Quitar de la lista del carrito en memoria
            repositorioCarrito.save(carrito); // Persistir el cambio en el carrito
        } else {
            throw new RuntimeException("El producto no se encontró en el carrito o no pertenece a este carrito.");
        }
    }

    @Transactional
    public void limpiarCarrito(Long carritoId) {
        Carrito carrito = repositorioCarrito.findById(carritoId)
                .orElseThrow(() -> new RuntimeException("Carrito no encontrado para limpiar."));
        carrito.getItems().clear();
        carrito.setCompletado(true); // Marca el carrito como completado después de una compra
        repositorioCarrito.save(carrito);
        session.removeAttribute("carritoId"); // Eliminar el carrito de la sesión
    }
}