package com.Duoc.DuocPickuUp.service;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.Compra;
import com.Duoc.DuocPickuUp.model.DetalleCompra;
import com.Duoc.DuocPickuUp.model.ItemCarrito;
import com.Duoc.DuocPickuUp.model.Producto;
import com.Duoc.DuocPickuUp.model.Usuario;
import com.Duoc.DuocPickuUp.repository.RepositorioCompra;
import com.Duoc.DuocPickuUp.repository.RepositorioDetalleCompra;
import jakarta.servlet.http.HttpSession; // Para limpiar el carrito de la sesión
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.List; // Importar List

@Service
public class ServicioCompra {

    @Autowired
    private RepositorioCompra repositorioCompra;

    @Autowired
    private RepositorioDetalleCompra repositorioDetalleCompra;

    @Autowired
    private ServicioCarrito servicioCarrito; // Para interactuar con el carrito

    @Autowired
    private ServicioProducto servicioProducto; // Para actualizar el stock

    @Autowired
    private HttpSession session; // Para gestionar la sesión

    @Transactional
    public Compra procesarCompra(
            String tipoTarjeta, String numeroTarjeta, String nombreTitular,
            String direccionEnvio, String ciudadEnvio, String codigoPostalEnvio,
            Usuario usuarioLogeado) {

        // 1. Validar y obtener el carrito actual
        Carrito carritoActual = servicioCarrito.obtenerCarritoActual();

        // Validar que el carrito no sea null y que tenga ítems
        if (carritoActual == null) {
            throw new RuntimeException("No se encontró un carrito de compras activo para la sesión actual.");
        }
        
        List<ItemCarrito> itemsCarrito = carritoActual.getItems();
        if (itemsCarrito == null || itemsCarrito.isEmpty()) {
            throw new RuntimeException("El carrito de compras está vacío. No se puede procesar una compra sin productos.");
        }

        // Validar que el usuario no sea null
        if (usuarioLogeado == null) {
            throw new RuntimeException("No hay un usuario logeado para procesar la compra.");
        }

        // 2. Crear la nueva compra
        Compra nuevaCompra = new Compra();
        nuevaCompra.setFechaCompra(LocalDateTime.now());
        nuevaCompra.setUsuario(usuarioLogeado); // Asignar el usuario a la compra

        // Establecer datos de pago
        nuevaCompra.setTipoTarjeta(tipoTarjeta);
        // Por seguridad, solo guarda los últimos 4 dígitos
        nuevaCompra.setUltimosCuatroDigitos(numeroTarjeta.substring(numeroTarjeta.length() - 4));
        nuevaCompra.setNombreTitular(nombreTitular);

        // Establecer datos de envío
        nuevaCompra.setDireccionEnvio(direccionEnvio);
        nuevaCompra.setCiudadEnvio(ciudadEnvio);
        nuevaCompra.setCodigoPostalEnvio(codigoPostalEnvio);

        double totalCompra = 0.0;

        // Iterar sobre los ítems del carrito para crear los detalles de compra
        // y actualizar el stock de productos
        for (ItemCarrito item : itemsCarrito) { // Usa itemsCarrito, que ya validamos que no es null
            // Validar que el producto y la cantidad del item no sean null
            if (item.getProducto() == null) {
                throw new RuntimeException("Uno de los productos en el carrito es inválido.");
            }
            if (item.getCantidad() == null || item.getCantidad() <= 0) {
                throw new RuntimeException("Cantidad inválida para el producto: " + item.getProducto().getNombre());
            }

            DetalleCompra detalle = new DetalleCompra();
            detalle.setCompra(nuevaCompra);
            detalle.setProducto(item.getProducto());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitarioEnCompra(item.getProducto().getPrecio()); // Guarda el precio en el momento de la compra

            totalCompra += item.getProducto().getPrecio() * item.getCantidad();

            nuevaCompra.getDetalles().add(detalle); // Añadir el detalle a la lista de detalles de la compra
                                                    // Es importante añadirlo a la lista de la compra ANTES de guardar la compra
                                                    // para que JPA maneje la cascada correctamente.
            
            // Actualizar el stock del producto
            Producto producto = item.getProducto();
            if (producto.getStock() < item.getCantidad()) {
                // Esto debería ser manejado antes (ej. en el controlador o servicio de carrito al agregar),
                // pero es una buena doble verificación para evitar inconsistencias graves.
                throw new RuntimeException("Stock insuficiente para el producto: " + producto.getNombre() + ". Stock disponible: " + producto.getStock());
            }
            producto.setStock(producto.getStock() - item.getCantidad());
            servicioProducto.guardarProducto(producto); // Guarda el producto con el stock actualizado
        }

        nuevaCompra.setTotal(totalCompra); // Establecer el total calculado

        // Guardar la compra y sus detalles
        repositorioCompra.save(nuevaCompra); // Esto guardará también los detalles por CascadeType.ALL

        // 3. Limpiar el carrito después de la compra exitosa
        // La lógica de limpiarCarrito en ServicioCarrito marcará el carrito como completado y eliminará el ID de la sesión.
        servicioCarrito.limpiarCarrito(carritoActual.getId());

        return nuevaCompra;
    }

    public Optional<Compra> obtenerCompraPorId(Long id) {
        return repositorioCompra.findById(id);
    }
}