package com.Duoc.DuocPickuUp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DuocPickuUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(DuocPickuUpApplication.class, args);
	}

}
