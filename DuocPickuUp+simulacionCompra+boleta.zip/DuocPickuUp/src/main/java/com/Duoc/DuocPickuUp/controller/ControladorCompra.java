package com.Duoc.DuocPickuUp.controller;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.Compra;
import com.Duoc.DuocPickuUp.model.Usuario; // Asegúrate de importar Usuario
import com.Duoc.DuocPickuUp.service.ServicioCarrito;
import com.Duoc.DuocPickuUp.service.ServicioCompra;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ControladorCompra {

    @Autowired
    private ServicioCompra servicioCompra;

    @Autowired
    private ServicioCarrito servicioCarrito;

    // Se ha eliminado el método 'mostrarCheckout' ya que no es parte del flujo de pago actual.
    // Si lo necesitas en el futuro para un checkout con envío, puedes volver a agregarlo.

    @GetMapping("/boleta/{id}")
    public String mostrarBoleta(@PathVariable Long id, Model modelo, RedirectAttributes redirectAttributes, HttpSession session) {
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");

        if (usuarioLogeado == null) {
            redirectAttributes.addFlashAttribute("error", "Debes iniciar sesión para ver tus boletas.");
            return "redirect:/auth/login"; // Redirige a la página de login si no hay usuario
        }

        return servicioCompra.obtenerCompraPorId(id)
            .map(compra -> {
                // Asegurarse de que el usuario logueado es el dueño de la compra
                // Se añade una comprobación adicional por si la compra.getUsuario() es null
                if (compra.getUsuario() == null || !compra.getUsuario().getId().equals(usuarioLogeado.getId())) {
                    redirectAttributes.addFlashAttribute("error", "No tienes permiso para ver esta boleta o la boleta no es tuya.");
                    return "redirect:/productos"; // O a una página de error de acceso denegado
                }
                modelo.addAttribute("compra", compra);
                modelo.addAttribute("carrito", servicioCarrito.obtenerCarritoActual()); // Añadir el carrito para el encabezado (opcional)
                return "boleta"; // Nombre de la plantilla HTML
            })
            .orElseGet(() -> {
                redirectAttributes.addFlashAttribute("error", "Boleta no encontrada.");
                return "redirect:/productos"; // O a la página de inicio
            });
    }
}