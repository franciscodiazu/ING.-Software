package com.Duoc.DuocPickuUp.controller;

import com.Duoc.DuocPickuUp.model.Producto;
import com.Duoc.DuocPickuUp.service.ServicioProducto;
import com.Duoc.DuocPickuUp.service.ServicioCarrito; // Importa ServicioCarrito
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/productos")
public class ControladorProducto {

    @Autowired
    private ServicioProducto servicioProducto;

    @Autowired
    private ServicioCarrito servicioCarrito; // Inyecta ServicioCarrito

    @GetMapping
    public String listarProductos(Model modelo) {
        modelo.addAttribute("productos", servicioProducto.obtenerTodosLosProductos());
        modelo.addAttribute("carrito", servicioCarrito.obtenerCarritoActual()); // Añadir el carrito al modelo
        return "lista-productos";
    }

    // Método para mostrar el formulario de agregar/editar producto
    @GetMapping("/nuevo")
    public String mostrarFormularioAgregarProducto(Model modelo) {
        modelo.addAttribute("producto", new Producto());
        modelo.addAttribute("titulo", "Agregar Nuevo Producto"); // Título para la página
        modelo.addAttribute("carrito", servicioCarrito.obtenerCarritoActual()); // Añadir el carrito
        return "formulario-producto";
    }

    // Método para mostrar el formulario de edición de producto
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditarProducto(@PathVariable Long id, Model modelo, RedirectAttributes redirectAttributes) {
        return servicioProducto.obtenerProductoPorId(id)
                .map(producto -> {
                    modelo.addAttribute("producto", producto);
                    modelo.addAttribute("titulo", "Editar Producto"); // Título para la página
                    modelo.addAttribute("carrito", servicioCarrito.obtenerCarritoActual()); // Añadir el carrito
                    return "formulario-producto";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("error", "Producto no encontrado para editar.");
                    return "redirect:/productos";
                });
    }

    // Método para guardar un nuevo producto o actualizar uno existente
    @PostMapping("/guardar")
    public String guardarProducto(Producto producto, RedirectAttributes atributosRedireccion) {
        servicioProducto.guardarProducto(producto);
        atributosRedireccion.addFlashAttribute("mensaje", "Producto guardado exitosamente!");
        return "redirect:/productos";
    }

    // Método para eliminar un producto
    @PostMapping("/eliminar/{id}")
    public String eliminarProducto(@PathVariable Long id, RedirectAttributes atributosRedireccion) {
        try {
            servicioProducto.eliminarProducto(id);
            atributosRedireccion.addFlashAttribute("mensaje", "Producto eliminado exitosamente!");
        } catch (RuntimeException e) {
            atributosRedireccion.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/productos";
    }
}