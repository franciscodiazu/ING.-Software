package com.Duoc.DuocPickuUp.repository;


import com.Duoc.DuocPickuUp.model.EstadoProducto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstadoProductoRepository extends JpaRepository<EstadoProducto, Long> {
}