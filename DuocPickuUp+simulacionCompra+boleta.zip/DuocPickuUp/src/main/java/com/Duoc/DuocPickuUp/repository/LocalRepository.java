package com.Duoc.DuocPickuUp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Duoc.DuocPickuUp.model.Local;

public interface LocalRepository extends JpaRepository<Local, Long> {}
