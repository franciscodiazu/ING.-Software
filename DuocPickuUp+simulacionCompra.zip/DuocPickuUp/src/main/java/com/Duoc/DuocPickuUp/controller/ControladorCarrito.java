package com.Duoc.DuocPickuUp.controller;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.Compra;
import com.Duoc.DuocPickuUp.model.Usuario; // Asegúrate de importar Usuario
import com.Duoc.DuocPickuUp.service.ServicioCarrito;
import com.Duoc.DuocPickuUp.service.ServicioCompra;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Map;

@Controller
@RequestMapping("/carrito")
public class ControladorCarrito {

    @Autowired
    private ServicioCompra servicioCompra;
    @Autowired
    private ServicioCarrito servicioCarrito;
    @Autowired
    private HttpSession session; // Inyecta HttpSession

    @GetMapping
    public String verCarrito(Model modelo) {
        // Obtener el usuario logeado de la sesión
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado"); //

        // Obtener el carrito actual. El servicio se encargará de crearlo/obtenerlo para el usuario o la sesión.
        Carrito carrito = servicioCarrito.obtenerCarritoActual(); //

        // Añadir el carrito y el usuario logeado al modelo
        modelo.addAttribute("carrito", carrito); //
        modelo.addAttribute("usuarioLogeado", usuarioLogeado); // Ahora es seguro añadirlo, puede ser null

        // Puedes añadir un mensaje si el carrito está vacío
        if (carrito == null || carrito.getItems().isEmpty()) { //
            modelo.addAttribute("mensaje", "Tu carrito está vacío."); //
        }

        return "carrito"; // Devuelve la plantilla carrito.html
    }

    @PostMapping("/agregar")
    public String agregarAlCarrito(@RequestParam Long productoId,
                                   @RequestParam(defaultValue = "1") int cantidad,
                                   RedirectAttributes redirectAttributes) {
        try {
            servicioCarrito.agregarProductoAlCarrito(productoId, cantidad); //
            redirectAttributes.addFlashAttribute("mensaje", "Producto añadido al carrito!"); //
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage()); //
        }
        return "redirect:/productos"; // Redirige de nuevo a la lista de productos
    }

    @PostMapping("/eliminar")
    public String eliminarDelCarrito(@RequestParam Long itemId, RedirectAttributes redirectAttributes) {
        try {
            servicioCarrito.eliminarProductoDelCarrito(itemId); //
            redirectAttributes.addFlashAttribute("mensaje", "Producto eliminado del carrito."); //
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage()); //
        }
        return "redirect:/carrito"; // Redirige de nuevo a la página del carrito
    }

    @PostMapping("/actualizarCantidad")
    public String actualizarCantidad(@RequestParam Long itemId, @RequestParam int cantidad, RedirectAttributes redirectAttributes) {
        try {
            servicioCarrito.actualizarCantidad(itemId, cantidad); //
            redirectAttributes.addFlashAttribute("mensaje", "Cantidad actualizada."); //
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage()); //
        }
        return "redirect:/carrito"; //
    }

    @PostMapping("/procesarPago")
    @ResponseBody // Indica que el método devuelve directamente el cuerpo de la respuesta, no una vista
    public ResponseEntity<?> procesarPago(@RequestBody Map<String, String> paymentData) {
        try {
            // Recuperar el usuario logeado de la sesión
            Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado"); //

            if (usuarioLogeado == null) { //
                // Si no hay usuario logeado, devuelve un error 401 Unauthorized
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Debes iniciar sesión para procesar el pago."); //
            }

            // AHORA SÍ, obtenemos el carrito para la compra, asegurándonos de que esté asociado al usuario logueado.
            // Utiliza el método diseñado para esto.
            Carrito carritoParaProcesar = servicioCarrito.obtenerCarritoActualParaCompra(usuarioLogeado); //

            // Validar que el carrito no esté nulo o vacío antes de pasarlo a ServicioCompra
            if (carritoParaProcesar == null || carritoParaProcesar.getItems().isEmpty()) { //
                throw new RuntimeException("Tu carrito está vacío o no se encontró un carrito activo para el usuario. No se puede procesar la compra.");
            }

            String nombreTitular = paymentData.get("nombre") + " " + paymentData.get("apellido"); //
            String numeroTarjeta = paymentData.get("numeroTarjeta"); //

            // Llama al método procesarCompra del ServicioCompra, pasando el carrito obtenido
            Compra compraRealizada = servicioCompra.procesarCompra(
                    "Credito", // Tipo de tarjeta
                    numeroTarjeta, //
                    nombreTitular, //
                    usuarioLogeado, // Pasamos el usuario logueado
                    carritoParaProcesar // <--- ¡AQUÍ ESTÁ EL CAMBIO CLAVE! Pasamos el carrito real.
            );

            // Devuelve el ID de la compra para que el frontend pueda redirigir a la boleta
            return ResponseEntity.ok(Map.of("compraId", compraRealizada.getId())); //

        } catch (RuntimeException e) {
            // Captura cualquier excepción y devuelve un mensaje de error al frontend
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage()); //
        }
    }

    // El método /vaciar ha sido eliminado ya que su lógica se integró en ServicioCompra.procesarCompra.
    // Si aún lo necesitas para otro propósito (ej. un botón de vaciar carrito sin comprar),
    // deberías reimplementar solo la lógica de vaciado sin afectar el stock o registrar compras.
}