// Suponiendo que tienes un EstudianteController
package com.Duoc.DuocPickuUp.controller;

import com.Duoc.DuocPickuUp.model.Estudiante;
import com.Duoc.DuocPickuUp.service.EstudianteService; // Importar el servicio
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {

    @Autowired
    private EstudianteService estudianteService; // Usar el servicio

    @GetMapping
    public List<Estudiante> getEstudiantes() {
        return estudianteService.listar();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Estudiante createEstudiante(@Valid @RequestBody Estudiante estudiante) {
        // La lógica de registro de estudiante para evitar duplicados está en AuthController
        // Este POST es para crear estudiantes por un admin ya existente, o si se desea permitir
        return estudianteService.guardar(estudiante);
    }

    @PutMapping("/{id}")
    public Estudiante updateEstudiante(@PathVariable Long id, @Valid @RequestBody Estudiante estudiante) {
        if (!estudianteService.buscar(id).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Estudiante no encontrado");
        }
        estudiante.setId(id);
        return estudianteService.guardar(estudiante);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteEstudiante(@PathVariable Long id) {
        if (!estudianteService.eliminar(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Estudiante no encontrado");
        }
    }
}