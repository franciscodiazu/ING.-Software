package com.Duoc.DuocPickuUp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Duoc.DuocPickuUp.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {}
