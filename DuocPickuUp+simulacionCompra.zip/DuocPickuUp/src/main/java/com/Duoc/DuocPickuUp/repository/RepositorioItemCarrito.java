package com.Duoc.DuocPickuUp.repository;

import com.Duoc.DuocPickuUp.model.ItemCarrito;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositorioItemCarrito extends JpaRepository<ItemCarrito, Long> {
    // Puedes añadir métodos personalizados aquí si los necesitas,
    // por ejemplo: List<ItemCarrito> findByCarritoId(Long carritoId);
}