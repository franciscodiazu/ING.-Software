package com.Duoc.DuocPickuUp.service;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.Compra;
import com.Duoc.DuocPickuUp.model.ItemCarrito;
import com.Duoc.DuocPickuUp.model.Producto;
import com.Duoc.DuocPickuUp.model.Usuario;
import com.Duoc.DuocPickuUp.repository.RepositorioCarrito;
import com.Duoc.DuocPickuUp.repository.RepositorioItemCarrito;
import com.Duoc.DuocPickuUp.repository.RepositorioProducto;
import com.Duoc.DuocPickuUp.service.ServicioProducto;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ServicioCarrito {

    private static final String CARRO_ID_SESSION_KEY = "carritoId";

    @Autowired
    private RepositorioCarrito repositorioCarrito;

    @Autowired
    private RepositorioProducto repositorioProducto;

    @Autowired
    private RepositorioItemCarrito repositorioItemCarrito;

    @Autowired
    private HttpSession session;

    @Autowired
    private ServicioProducto servicioProducto;

    public Carrito obtenerCarritoActual() {
        Long carritoId = (Long) session.getAttribute(CARRO_ID_SESSION_KEY);
        Carrito carrito;

        if (carritoId != null) {
            carrito = repositorioCarrito.findById(carritoId)
                    .orElse(null);
            if (carrito != null && !carrito.isCompletado()) {
                return carrito;
            }
        }

        carrito = new Carrito();
        carrito.setFechaCreacion(LocalDateTime.now());
        carrito.setCompletado(false);
        // If a user is logged in, associate the new cart with them.
        // This assumes the usuarioLogeado attribute is set in the session upon login.
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");
        if (usuarioLogeado != null) {
            // Check if there's already an uncompleted cart for this user in the DB
            Optional<Carrito> existingUserCart = repositorioCarrito.findByUsuarioAndCompletadoFalse(usuarioLogeado);
            if (existingUserCart.isPresent()) {
                return existingUserCart.get(); // Return the existing user-specific cart
            }
            carrito.setUsuario(usuarioLogeado);
        }

        carrito = repositorioCarrito.save(carrito);
        session.setAttribute(CARRO_ID_SESSION_KEY, carrito.getId());
        return carrito;
    }

    public Carrito obtenerCarritoActualParaCompra(Usuario usuario) {
        if (usuario == null) {
            throw new RuntimeException("Usuario no logueado. No se puede procesar la compra sin un usuario.");
        }
        // Intenta encontrar un carrito no completado asociado a este usuario
        Optional<Carrito> carritoExistente = repositorioCarrito.findByUsuarioAndCompletadoFalse(usuario);

        if (carritoExistente.isPresent()) {
            return carritoExistente.get();
        } else {
            // If no existing cart for the user, create a new one and associate it
            Carrito nuevoCarrito = new Carrito();
            nuevoCarrito.setFechaCreacion(LocalDateTime.now());
            nuevoCarrito.setCompletado(false);
            nuevoCarrito.setUsuario(usuario);
            return repositorioCarrito.save(nuevoCarrito);
        }
    }

    @Transactional
    public void agregarProductoAlCarrito(Long productoId, int cantidad) {
        Producto producto = repositorioProducto.findById(productoId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado."));

        if (producto.getStock() < cantidad) {
            throw new RuntimeException("No hay suficiente stock para el producto: " + producto.getNombre());
        }

        Carrito carrito = obtenerCarritoActual();

        carrito.agregarProducto(producto, cantidad);

        repositorioCarrito.save(carrito);
    }

    @Transactional
    public void eliminarProductoDelCarrito(Long itemId) {
        ItemCarrito item = repositorioItemCarrito.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Ítem del carrito no encontrado."));

        Carrito carrito = item.getCarrito();
        carrito.eliminarProducto(itemId);

        repositorioCarrito.save(carrito);
    }

    @Transactional
    public void limpiarCarrito(Long carritoId) {
        Optional<Carrito> carritoOptional = repositorioCarrito.findById(carritoId);
        if (carritoOptional.isPresent()) {
            Carrito carrito = carritoOptional.get();
            carrito.limpiarCarrito();
            repositorioCarrito.save(carrito);
            session.removeAttribute(CARRO_ID_SESSION_KEY);
        }
    }

    @Transactional
    public Compra procesarCompra(String tipoTarjeta, String numeroTarjeta, String nombreTitular, Usuario usuario) {
        // Use the method that specifically retrieves the cart for the logged-in user
        Carrito carritoActual = obtenerCarritoActualParaCompra(usuario); // <--- CHANGE IS HERE

        if (carritoActual == null || carritoActual.getItems() == null || carritoActual.getItems().isEmpty()) {
            throw new RuntimeException("Tu carrito está vacío o no se encontró un carrito activo para el usuario. No se puede procesar la compra.");
        }

        // Validate stock and products
        for (ItemCarrito item : carritoActual.getItems()) {
            if (item.getProducto() == null) {
                throw new RuntimeException("Error: Un producto en el carrito es nulo.");
            }
            Producto producto = servicioProducto.obtenerProductoPorId(item.getProducto().getId())
                    .orElseThrow(() -> new RuntimeException("Producto con ID " + item.getProducto().getId() + " no encontrado en el inventario."));
            if (item.getCantidad() > producto.getStock()) {
                throw new RuntimeException("No hay suficiente stock para el producto: " + producto.getNombre() + ". Stock disponible: " + producto.getStock());
            }
        }
        // TODO: Implement the actual purchase processing logic here:
        // 1. Create a new Compra entity.
        // 2. Associate items from carritoActual to the Compra.
        // 3. Update product stock (subtract purchased quantities).
        // 4. Set carritoActual.setCompletado(true) and clear its items.
        // 5. Save Compra and updated Producto entities.
        // 6. Return the created Compra.

        // For now, returning null as per original code, but this needs proper implementation.
        return null;
    }

    @Transactional
    public void actualizarCantidad(Long itemId, int nuevaCantidad) {
        if (nuevaCantidad <= 0) {
            eliminarProductoDelCarrito(itemId);
            return;
        }
        // TODO: Add logic to find the item and update its quantity if nuevaCantidad > 0
        Optional<ItemCarrito> itemOptional = repositorioItemCarrito.findById(itemId);
        if (itemOptional.isPresent()) {
            ItemCarrito item = itemOptional.get();
            item.setCantidad(nuevaCantidad);
            repositorioItemCarrito.save(item);
        } else {
            throw new RuntimeException("Ítem del carrito no encontrado para actualizar cantidad.");
        }
    }
}