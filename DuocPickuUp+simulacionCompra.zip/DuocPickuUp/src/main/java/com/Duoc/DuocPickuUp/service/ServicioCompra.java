package com.Duoc.DuocPickuUp.service;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.Compra;
import com.Duoc.DuocPickuUp.model.DetalleCompra;
import com.Duoc.DuocPickuUp.model.ItemCarrito;
import com.Duoc.DuocPickuUp.model.Producto;
import com.Duoc.DuocPickuUp.model.Usuario;
import com.Duoc.DuocPickuUp.repository.RepositorioCarrito;
import com.Duoc.DuocPickuUp.repository.RepositorioCompra;
import com.Duoc.DuocPickuUp.repository.RepositorioDetalleCompra;
import com.Duoc.DuocPickuUp.repository.RepositorioProducto;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.ArrayList;
import java.util.List;

@Service
public class ServicioCompra {

    @Autowired
    private RepositorioCompra repositorioCompra;

    @Autowired
    private RepositorioDetalleCompra RepositorioDetalleCompra;

    @Autowired
    private RepositorioCarrito RepositorioCarrito;

    @Autowired
    private ServicioCarrito servicioCarrito; // Necesitas el servicio de carrito para limpiar

    @Autowired
    private ServicioProducto servicioProducto; // Para actualizar el stock (anteriormente RepositorioProducto)

    @Autowired
    private HttpSession session; // Para interactuar con la sesión, principalmente para limpiar el carrito


    @Transactional
    public Compra procesarCompra(String tipoTarjeta, String numeroTarjetaCompleto, String nombreTitular, Usuario usuario, Carrito carritoActual) {
        // Validación del carrito antes de proceder
        if (carritoActual == null || carritoActual.getItems().isEmpty()) {
            throw new RuntimeException("El carrito está vacío o no es válido para procesar la compra.");
        }

        // 1. Crear la nueva Compra
        Compra nuevaCompra = new Compra();
        nuevaCompra.setFechaCompra(LocalDateTime.now());
        nuevaCompra.setUsuario(usuario);
        nuevaCompra.setTipoTarjeta(tipoTarjeta);
        // Almacenar solo los últimos 4 dígitos de la tarjeta
        if (numeroTarjetaCompleto != null && numeroTarjetaCompleto.length() > 4) {
            nuevaCompra.setUltimosCuatroDigitos(numeroTarjetaCompleto.substring(numeroTarjetaCompleto.length() - 4));
        } else {
            nuevaCompra.setUltimosCuatroDigitos(numeroTarjetaCompleto); // O manejar como error si es muy corto
        }
        nuevaCompra.setNombreTitular(nombreTitular);

        // *** LA MODIFICACIÓN CLAVE PARA RESOLVER EL ERROR 'metodo_pago' ***
        // Asigna un valor para el campo 'metodoPago'. Puedes usar el tipo de tarjeta
        // o un valor más genérico como "Tarjeta de Crédito" si es el único método.
        nuevaCompra.setMetodoPago("Tarjeta de Crédito"); // O podrías usar 'tipoTarjeta' si se ajusta a lo que esperas en 'metodo_pago'

        // 2. Procesar los ítems del carrito para crear DetalleCompra y actualizar stock
        List<DetalleCompra> detalles = new ArrayList<>();
        double totalCompra = 0.0;

        for (ItemCarrito item : carritoActual.getItems()) {
            Producto producto = item.getProducto();

            // Verificar si hay suficiente stock antes de procesar
            if (producto.getStock() < item.getCantidad()) {
                throw new RuntimeException("No hay suficiente stock para el producto: " + producto.getNombre() + ". Stock disponible: " + producto.getStock());
            }

            // Actualizar el stock del producto
            producto.setStock(producto.getStock() - item.getCantidad());
            servicioProducto.guardarProducto(producto); // Guarda el producto con el stock actualizado

            // Crear DetalleCompra
            DetalleCompra detalle = new DetalleCompra();
            detalle.setProducto(producto);
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitarioEnCompra(item.getProducto().getPrecio());
            detalle.setCompra(nuevaCompra); // Establecer la relación bidireccional
            detalles.add(detalle);

            totalCompra += item.getProducto().getPrecio() * item.getCantidad();
        }

        nuevaCompra.setDetalles(detalles); // Asignar los detalles a la compra
        nuevaCompra.setTotal(totalCompra); // Establecer el total calculado

        // Guardar la compra y sus detalles (por CascadeType.ALL en Compra)
        repositorioCompra.save(nuevaCompra);

        // 4. Limpiar el carrito después de la compra exitosa
        // Esto también marca el carrito como completado y elimina el ID de la sesión.
        servicioCarrito.limpiarCarrito(carritoActual.getId());

        return nuevaCompra;
    }

    public Optional<Compra> obtenerCompraPorId(Long id) {
        return repositorioCompra.findById(id);
    }
}