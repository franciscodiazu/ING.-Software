package com.Duoc.DuocPickuUp.controller;


import com.Duoc.DuocPickuUp.model.CategoriaProducto;
import com.Duoc.DuocPickuUp.service.CategoriaProductoService; // Importar el servicio
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/categorias")
public class CategoriaProductoController {

    @Autowired
    private CategoriaProductoService categoriaProductoService; // Usar el servicio

    @GetMapping
    public List<CategoriaProducto> getCategorias() {
        return categoriaProductoService.listar(); // Llamar al servicio
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CategoriaProducto createCategoria(@Valid @RequestBody CategoriaProducto categoriaProducto) {
        return categoriaProductoService.guardar(categoriaProducto); // Llamar al servicio
    }

    @PutMapping("/{id}")
    public CategoriaProducto updateCategoria(@PathVariable Long id, @Valid @RequestBody CategoriaProducto categoriaProducto) {
        if (!categoriaProductoService.buscar(id).isPresent()) { // Llamar al servicio
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Categoría no encontrada");
        }
        categoriaProducto.setId(id);
        return categoriaProductoService.guardar(categoriaProducto); // Llamar al servicio
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCategoria(@PathVariable Long id) {
        if (!categoriaProductoService.eliminar(id)) { // Llamar al servicio
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Categoría no encontrada");
        }
    }
}