package com.Duoc.DuocPickuUp.controller;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.Compra;
import com.Duoc.DuocPickuUp.model.Usuario;
import com.Duoc.DuocPickuUp.service.ServicioCarrito;
import com.Duoc.DuocPickuUp.service.ServicioCompra;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable; // No necesario para esta opción
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Map;

@Controller
@RequestMapping("/carrito")
public class ControladorCarrito {

    @Autowired
    private ServicioCompra servicioCompra;
    @Autowired
    private ServicioCarrito servicioCarrito;

    @GetMapping
    public String verCarrito(Model modelo, HttpSession session) {
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");
        if (usuarioLogeado == null) {
            modelo.addAttribute("error", "Debes iniciar sesión para ver tu carrito.");
            return "redirect:/auth/login";
        }
        Carrito carritoActual = servicioCarrito.obtenerCarritoActual();
        modelo.addAttribute("carrito", carritoActual);
        modelo.addAttribute("totalCarrito", carritoActual.getTotal());
        return "carrito";
    }

    @PostMapping("/agregar")
    public String agregarProductoAlCarrito(@RequestParam("productoId") Long productoId,
                                           @RequestParam(defaultValue = "1") int cantidad,
                                           RedirectAttributes atributosRedireccion,
                                           HttpSession session) {
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");
        if (usuarioLogeado == null) {
            atributosRedireccion.addFlashAttribute("error", "Debes iniciar sesión para agregar productos al carrito.");
            return "redirect:/auth/login";
        }
        try {
            servicioCarrito.agregarProductoAlCarrito(productoId, cantidad);
            atributosRedireccion.addFlashAttribute("mensaje", "Producto agregado al carrito!");
        } catch (RuntimeException e) {
            atributosRedireccion.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/productos";
    }

    // Método modificado para usar @RequestParam
    @PostMapping("/eliminar") // Eliminar {itemId} de la ruta
    public String eliminarProductoDelCarrito(@RequestParam("itemId") Long itemId, // Usar @RequestParam
                                           RedirectAttributes atributosRedireccion,
                                           HttpSession session) {
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");
        if (usuarioLogeado == null) {
            atributosRedireccion.addFlashAttribute("error", "Debes iniciar sesión para modificar el carrito.");
            return "redirect:/auth/login";
        }
        try {
            servicioCarrito.eliminarProductoDelCarrito(itemId);
            atributosRedireccion.addFlashAttribute("mensaje", "Producto eliminado del carrito!");
        } catch (RuntimeException e) {
            atributosRedireccion.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/carrito"; // Redirige de nuevo a la vista del carrito
    }

    @PostMapping("/procesarPago")
    @ResponseBody
    public ResponseEntity<?> procesarPago(@RequestBody Map<String, String> paymentData, HttpSession session) {
        try {
            Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");
            if (usuarioLogeado == null) {
                usuarioLogeado = new Usuario();
                usuarioLogeado.setId(1L);
                usuarioLogeado.setNombre(paymentData.get("nombre"));
                usuarioLogeado.setApellido(paymentData.get("apellido"));
                usuarioLogeado.setCorreo("usuario@example.com");
            }

            String nombreTitular = paymentData.get("nombre") + " " + paymentData.get("apellido");
            String numeroTarjeta = paymentData.get("numeroTarjeta");

            Carrito carritoParaProcesar = servicioCarrito.obtenerCarritoActual();

            Compra compraRealizada = servicioCompra.procesarCompra(
                    "Credito",
                    numeroTarjeta,
                    nombreTitular,
                    usuarioLogeado
            );

            return ResponseEntity.ok(Map.of("compraId", compraRealizada.getId()));

        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }
}