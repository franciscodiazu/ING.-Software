package com.Duoc.DuocPickuUp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Duoc.DuocPickuUp.model.CategoriaProducto;

public interface CategoriaProductoRepository extends JpaRepository<CategoriaProducto, Long> {}

