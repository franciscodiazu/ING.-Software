package com.Duoc.DuocPickuUp.repository;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.Usuario;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositorioCarrito extends JpaRepository<Carrito, Long> {
    Carrito findByCompletadoFalse();

    Optional<Carrito> findByUsuarioAndCompletadoFalse(Usuario usuarioLogeado);

    // Añade este método:
    Optional<Carrito> findByUsuario(Usuario usuario);
}
