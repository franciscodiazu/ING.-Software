package com.Duoc.DuocPickuUp.repository;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.ItemCarrito;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositorioItemCarrito extends JpaRepository<ItemCarrito, Long> { //
    // Puedes añadir métodos personalizados aquí si los necesitas,
    // por ejemplo: List<ItemCarrito> findByCarritoId(Long carritoId);
    List<ItemCarrito> findByCarrito(Carrito carrito); // Nuevo método para encontrar ítems por carrito
}