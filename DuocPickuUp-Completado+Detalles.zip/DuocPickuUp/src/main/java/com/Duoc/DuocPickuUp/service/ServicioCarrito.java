package com.Duoc.DuocPickuUp.service;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.ItemCarrito;
import com.Duoc.DuocPickuUp.model.Producto;
import com.Duoc.DuocPickuUp.model.Usuario;
import com.Duoc.DuocPickuUp.repository.RepositorioCarrito;
import com.Duoc.DuocPickuUp.repository.RepositorioItemCarrito;
import com.Duoc.DuocPickuUp.repository.RepositorioProducto;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import java.time.LocalDateTime;
import java.util.Optional;
@Service
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ServicioCarrito {

    private static final String CARRO_ID_SESSION_KEY = "carritoId";

    @Autowired
    private RepositorioCarrito repositorioCarrito;

    @Autowired
    private RepositorioItemCarrito repositorioItemCarrito;

    @Autowired
    private ServicioProducto servicioProducto; // Asegúrate de que este también esté inyectado

    @Autowired
    private RepositorioProducto repositorioProducto; // Necesario para actualizar stock

    @Autowired
    private HttpSession session;

    // Método para obtener el carrito actual del usuario o crear uno nuevo
    @Transactional //
    public Carrito obtenerCarritoActual() {
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado"); //
        Carrito carrito = null;

        if (usuarioLogeado != null) {
            // 1. Intenta encontrar un carrito NO completado para el usuario.
            Optional<Carrito> carritoActivo = repositorioCarrito.findByUsuarioAndCompletadoFalse(usuarioLogeado); //

            if (carritoActivo.isPresent()) {
                carrito = carritoActivo.get(); //
            } else {
                // 2. Si no hay un carrito NO completado, busca CUALQUIER carrito para este usuario.
                // Esto es crucial para reusar carritos previamente completados o si la restricción es solo por usuario_id
                Optional<Carrito> cualquierCarritoExistente = repositorioCarrito.findByUsuario(usuarioLogeado); //

                if (cualquierCarritoExistente.isPresent()) {
                    carrito = cualquierCarritoExistente.get();
                    // Reactiva el carrito si estaba completado y lo limpia para un nuevo uso
                    if (carrito.isCompletado()) { //
                        carrito.setCompletado(false); //
                        carrito.getItems().clear(); // Limpia los ítems viejos
                        repositorioItemCarrito.deleteAll(repositorioItemCarrito.findByCarrito(carrito)); // Elimina los items de la DB
                        repositorioCarrito.save(carrito); // Guarda los cambios del carrito
                    }
                } else {
                    // 3. Si no hay ningún carrito para el usuario (ni activo ni completado), crea uno nuevo.
                    carrito = new Carrito(); //
                    carrito.setFechaCreacion(LocalDateTime.now()); //
                    carrito.setCompletado(false); //
                    carrito.setUsuario(usuarioLogeado); //
                    carrito = repositorioCarrito.save(carrito); //
                }
            }
            session.setAttribute(CARRO_ID_SESSION_KEY, carrito.getId()); // Asegúrate de mantener el ID del carrito en la sesión
        } else {
            // Lógica para usuarios no logueados (como ya la tienes)
            Long carritoId = (Long) session.getAttribute(CARRO_ID_SESSION_KEY); //
            if (carritoId != null) {
                carrito = repositorioCarrito.findById(carritoId).orElse(null); //
            }

            if (carrito == null) {
                carrito = new Carrito(); //
                carrito.setFechaCreacion(LocalDateTime.now()); //
                carrito.setCompletado(false); //
                carrito = repositorioCarrito.save(carrito); //
                session.setAttribute(CARRO_ID_SESSION_KEY, carrito.getId()); // Guarda el ID en sesión
            }
        }
        return carrito;
    }

    private Carrito crearNuevoCarrito(Usuario usuario) {
        Carrito nuevoCarrito = new Carrito();
        nuevoCarrito.setFechaCreacion(LocalDateTime.now());
        nuevoCarrito.setCompletado(false);
        nuevoCarrito.setUsuario(usuario); // Asignar el usuario al carrito
        repositorioCarrito.save(nuevoCarrito);
        session.setAttribute("carritoId", nuevoCarrito.getId());
        return nuevoCarrito;
    }

    @Transactional
    public void agregarProductoAlCarrito(Long productoId, int cantidad) {
        // Asume que ya tienes un usuario logueado en la sesión para obtener el carrito
        // O pasa el usuario como parámetro si este método puede ser llamado sin un usuario en sesión
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");
        if (usuarioLogeado == null) {
            throw new RuntimeException("Debe iniciar sesión para agregar productos al carrito.");
        }

        Carrito carrito = obtenerCarritoActual();
        Producto producto = servicioProducto.obtenerProductoPorId(productoId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado."));

        if (producto.getStock() < cantidad) {
            throw new RuntimeException("Stock insuficiente para el producto: " + producto.getNombre() + ". Stock disponible: " + producto.getStock());
        }

        Optional<ItemCarrito> existingItem = carrito.getItems().stream()
                .filter(item -> item.getProducto().getId().equals(productoId))
                .findFirst();

        if (existingItem.isPresent()) {
            ItemCarrito item = existingItem.get();
            if (producto.getStock() < (item.getCantidad() + cantidad)) {
                 throw new RuntimeException("No hay suficiente stock para el producto: " + producto.getNombre() + ". Stock disponible: " + producto.getStock() + ". Cantidad actual en carrito: " + item.getCantidad());
            }
            item.setCantidad(item.getCantidad() + cantidad);
            repositorioItemCarrito.save(item);
        } else {
            ItemCarrito newItem = new ItemCarrito();
            newItem.setProducto(producto);
            newItem.setCantidad(cantidad);
            newItem.setCarrito(carrito);
            repositorioItemCarrito.save(newItem);
            carrito.getItems().add(newItem); // Asegúrate de agregar el nuevo item a la lista del carrito en memoria
        }
        repositorioCarrito.save(carrito);
    }

    @Transactional
    public void eliminarProductoDelCarrito(Long itemId) {
        Usuario usuarioLogeado = (Usuario) session.getAttribute("usuarioLogeado");
        if (usuarioLogeado == null) {
            throw new RuntimeException("Debe iniciar sesión para modificar el carrito.");
        }

        Carrito carrito = obtenerCarritoActual();
        Optional<ItemCarrito> itemToRemove = repositorioItemCarrito.findById(itemId);

        if (itemToRemove.isPresent() && itemToRemove.get().getCarrito().getId().equals(carrito.getId())) {
            repositorioItemCarrito.delete(itemToRemove.get());
            carrito.getItems().remove(itemToRemove.get());
            repositorioCarrito.save(carrito);
        } else {
            throw new RuntimeException("El producto no se encontró en el carrito o no pertenece a este carrito.");
        }
    }

    @Transactional
    public void limpiarCarrito(Long carritoId) {
        Carrito carrito = repositorioCarrito.findById(carritoId)
                .orElseThrow(() -> new RuntimeException("Carrito no encontrado para limpiar."));
        carrito.getItems().clear();
        carrito.setCompletado(true);
        repositorioCarrito.save(carrito);
        session.removeAttribute("carritoId");
    }

    @Transactional
    public void actualizarCantidad(Long itemId, int nuevaCantidad) {
        Optional<ItemCarrito> itemOptional = repositorioItemCarrito.findById(itemId);
        if (itemOptional.isPresent()) {
            ItemCarrito item = itemOptional.get();
            Producto producto = item.getProducto();

            if (nuevaCantidad <= 0) {
                eliminarProductoDelCarrito(itemId);
                return;
            }

            if (producto.getStock() < nuevaCantidad) {
                throw new RuntimeException("No hay suficiente stock para el producto: " + producto.getNombre() + ". Stock disponible: " + producto.getStock());
            }

            item.setCantidad(nuevaCantidad);
            repositorioItemCarrito.save(item);
        } else {
            throw new RuntimeException("Ítem del carrito no encontrado para actualizar cantidad.");
        }
    }
}