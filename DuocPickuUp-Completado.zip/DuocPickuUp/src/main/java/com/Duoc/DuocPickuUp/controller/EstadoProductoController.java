package com.Duoc.DuocPickuUp.controller;

import com.Duoc.DuocPickuUp.model.EstadoProducto;
import com.Duoc.DuocPickuUp.service.EstadoProductoService; // Importar el servicio
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/estado-productos")
public class EstadoProductoController {

    @Autowired
    private EstadoProductoService estadoProductoService; // Usar el servicio

    @GetMapping
    public List<EstadoProducto> getEstadoProductos() {
        return estadoProductoService.findAll(); // Llamar al servicio
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EstadoProducto createEstadoProducto(@Valid @RequestBody EstadoProducto estadoProducto) {
        return estadoProductoService.save(estadoProducto); // Llamar al servicio
    }

    @PutMapping("/{id}")
    public EstadoProducto updateEstadoProducto(@PathVariable Long id, @Valid @RequestBody EstadoProducto estadoProducto) {
        if (!estadoProductoService.existsById(id)) { // Llamar al servicio
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Estado de producto no encontrado");
        }
        estadoProducto.setId(id);
        return estadoProductoService.save(estadoProducto); // Llamar al servicio
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteEstadoProducto(@PathVariable Long id) {
        if (!estadoProductoService.existsById(id)) { // Llamar al servicio
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Estado de producto no encontrado");
        }
        estadoProductoService.deleteById(id); // Llamar al servicio
    }
}