// Suponiendo que tienes un LocalController
package com.Duoc.DuocPickuUp.controller;

import com.Duoc.DuocPickuUp.model.Local;
import com.Duoc.DuocPickuUp.service.LocalService; // Importar el servicio
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/locales")
public class LocalController {

    @Autowired
    private LocalService localService; // Usar el servicio

    @GetMapping
    public List<Local> getLocales() {
        return localService.listar();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Local createLocal(@Valid @RequestBody Local local) {
        return localService.guardar(local);
    }

    @PutMapping("/{id}")
    public Local updateLocal(@PathVariable Long id, @Valid @RequestBody Local local) {
        if (!localService.buscar(id).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Local no encontrado");
        }
        local.setId(id);
        return localService.guardar(local);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteLocal(@PathVariable Long id) {
        if (!localService.eliminar(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Local no encontrado");
        }
    }
}