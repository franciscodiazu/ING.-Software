package com.Duoc.DuocPickuUp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.OneToOne; // Agregamos OneToOne para la relación con Usuario
import jakarta.persistence.JoinColumn; // Para la JoinColumn
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional; // Importar Optional
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Carrito {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime fechaCreacion;
    private boolean completado; // Para marcar si el carrito ya fue usado para una compra

    // Relación OneToOne con Usuario. Un carrito pertenece a un único usuario (logueado).
    // Esto asegura que el carrito esté asociado a la sesión de un usuario específico.
    @OneToOne
    @JoinColumn(name = "usuario_id", unique = false) // 'unique = true' para asegurar 1 a 1
    private Usuario usuario; // El usuario al que pertenece este carrito

    @OneToMany(mappedBy = "carrito", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemCarrito> items = new ArrayList<>(); // Asegúrate de inicializar la lista

    // Constructor personalizado si necesitas inicialización específica
    // @Builder // Si usas Lombok @Builder, puedes quitar este
    // public Carrito() {
    //     this.fechaCreacion = LocalDateTime.now();
    //     this.completado = false;
    //     this.items = new ArrayList<>();
    // }

    // Calcula el total del carrito dinámicamente
    public double getTotal() {
        return items.stream()
                .mapToDouble(item -> item.getProducto().getPrecio() * item.getCantidad())
                .sum();
    }

    // Método de conveniencia para agregar un producto al carrito
    public void agregarProducto(Producto producto, int cantidad) {
        // Busca si el producto ya está en el carrito
        Optional<ItemCarrito> existingItem = items.stream()
                .filter(item -> item.getProducto().getId().equals(producto.getId()))
                .findFirst();

        if (existingItem.isPresent()) {
            // Si el producto ya está, actualiza la cantidad
            ItemCarrito item = existingItem.get();
            item.setCantidad(item.getCantidad() + cantidad);
        } else {
            // Si el producto no está, crea un nuevo ItemCarrito
            ItemCarrito newItem = new ItemCarrito();
            newItem.setProducto(producto);
            newItem.setCantidad(cantidad);
            newItem.setCarrito(this); // Asegúrate de establecer la referencia al carrito
            this.items.add(newItem);
        }
    }

    // Método de conveniencia para eliminar un producto del carrito por el ID del ItemCarrito
    public void eliminarProducto(Long itemId) {
        // Busca el itemCarrito por su ID y lo elimina
        this.items.removeIf(item -> item.getId().equals(itemId));
    }

    // Método para limpiar el carrito después de una compra
    public void limpiarCarrito() {
        this.items.clear();
        this.completado = true; // Marca el carrito como completado para que no se use más para nuevas compras
    }
}