package com.Duoc.DuocPickuUp.service;

import com.Duoc.DuocPickuUp.model.Carrito;
import com.Duoc.DuocPickuUp.model.Compra;
import com.Duoc.DuocPickuUp.model.DetalleCompra;
import com.Duoc.DuocPickuUp.model.ItemCarrito;
import com.Duoc.DuocPickuUp.model.Producto;
import com.Duoc.DuocPickuUp.model.Usuario;
import com.Duoc.DuocPickuUp.repository.RepositorioCompra;
import com.Duoc.DuocPickuUp.repository.RepositorioDetalleCompra;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.ArrayList;
import java.util.List;

@Service
public class ServicioCompra {

    @Autowired
    private RepositorioCompra repositorioCompra;

    @Autowired
    private RepositorioDetalleCompra repositorioDetalleCompra;

    @Autowired
    private ServicioCarrito servicioCarrito;

    @Autowired
    private ServicioProducto servicioProducto;

    @Autowired
    private HttpSession session;


    @Transactional
    public Compra procesarCompra(String tipoTarjeta, String numeroTarjeta, String nombreTitular, Usuario usuario) {
        // 1. Obtener el carrito actual del usuario
        Carrito carritoActual = servicioCarrito.obtenerCarritoActual();
        if (carritoActual == null || carritoActual.getItems().isEmpty()) {
            throw new RuntimeException("El carrito está vacío o no existe.");
        }

        // 2. Crear una nueva compra
        Compra nuevaCompra = new Compra();
        nuevaCompra.setFechaCompra(LocalDateTime.now());
        nuevaCompra.setTipoTarjeta(tipoTarjeta);
        // Guardar solo los últimos 4 dígitos de la tarjeta
        if (numeroTarjeta != null && numeroTarjeta.length() > 4) {
            nuevaCompra.setUltimosCuatroDigitos(numeroTarjeta.substring(numeroTarjeta.length() - 4));
        } else {
            nuevaCompra.setUltimosCuatroDigitos(numeroTarjeta); // O manejar como error si es muy corto
        }
        nuevaCompra.setNombreTitular(nombreTitular);
        nuevaCompra.setUsuario(usuario);
        
        // ¡AGREGA ESTA LÍNEA PARA ASIGNAR EL MÉTODO DE PAGO!
        // Asumiendo que 'tipoTarjeta' es lo que quieres para 'metodoPago'
        nuevaCompra.setMetodoPago(tipoTarjeta); 

        List<DetalleCompra> detalles = new ArrayList<>();
        double totalCompra = 0;

        for (ItemCarrito item : carritoActual.getItems()) {
            Producto producto = item.getProducto();
            if (producto.getStock() < item.getCantidad()) {
                throw new RuntimeException("Stock insuficiente para el producto: " + producto.getNombre());
            }

            // Descontar stock
            producto.setStock(producto.getStock() - item.getCantidad());
            servicioProducto.guardarProducto(producto); // Guarda el producto con el stock actualizado

            DetalleCompra detalle = new DetalleCompra();
            detalle.setProducto(producto);
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitarioEnCompra(item.getProducto().getPrecio());
            detalle.setCompra(nuevaCompra);
            detalles.add(detalle);

            totalCompra += item.getProducto().getPrecio() * item.getCantidad();
        }

        nuevaCompra.setDetalles(detalles);
        nuevaCompra.setTotal(totalCompra);

        // Guardar la compra y sus detalles
        repositorioCompra.save(nuevaCompra); // Esto guardará también los detalles por CascadeType.ALL

        // 3. Limpiar el carrito después de la compra exitosa
        servicioCarrito.limpiarCarrito(carritoActual.getId());

        return nuevaCompra;
    }

    public Optional<Compra> obtenerCompraPorId(Long id) {
        return repositorioCompra.findById(id);
    }
}