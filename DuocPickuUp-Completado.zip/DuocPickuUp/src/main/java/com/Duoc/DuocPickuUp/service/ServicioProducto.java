package com.Duoc.DuocPickuUp.service;

import com.Duoc.DuocPickuUp.model.Producto;
import com.Duoc.DuocPickuUp.repository.RepositorioProducto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServicioProducto {

    @Autowired
    private RepositorioProducto repositorioProducto;

    public List<Producto> obtenerTodosLosProductos() {
        return repositorioProducto.findAll();
    }

    public Optional<Producto> obtenerProductoPorId(Long id) {
        return repositorioProducto.findById(id);
    }

    public Producto guardarProducto(Producto producto) {
        return repositorioProducto.save(producto);
    }

    public void eliminarProducto(Long id) {
        repositorioProducto.deleteById(id);
    }

    public boolean actualizarStockProducto(Long idProducto, int cantidad) {
        Optional<Producto> productoOpcional = repositorioProducto.findById(idProducto);
        if (productoOpcional.isPresent()) {
            Producto producto = productoOpcional.get();
            if (producto.getStock() >= cantidad) {
                producto.setStock(producto.getStock() - cantidad);
                repositorioProducto.save(producto);
                return true;
            }
        }
        return false;
    }
}