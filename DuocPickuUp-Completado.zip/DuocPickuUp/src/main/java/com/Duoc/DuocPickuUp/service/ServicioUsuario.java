package com.Duoc.DuocPickuUp.service;

import com.Duoc.DuocPickuUp.model.Usuario;
import com.Duoc.DuocPickuUp.repository.RepositorioUsuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; // Si usas BCrypt

import java.util.Optional;

@Service
public class ServicioUsuario {

    @Autowired
    private RepositorioUsuario repositorioUsuario;

    // Si estás usando Spring Security, necesitarías un PasswordEncoder
    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder(); // Instancia directa, en un proyecto real se inyecta

    public Optional<Usuario> buscarUsuarioPorCorreo(String correo) {
        return repositorioUsuario.findByCorreo(correo);
    }

    public Usuario registrarUsuario(Usuario usuario) {
        // Hashea la contraseña antes de guardarla
        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));
        return repositorioUsuario.save(usuario);
    }

    public Usuario autenticarUsuario(String correo, String contrasena) {
        Optional<Usuario> usuarioOpt = repositorioUsuario.findByCorreo(correo);
        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            // Compara la contraseña en texto plano con la hasheada
            if (passwordEncoder.matches(contrasena, usuario.getContrasena())) {
                return usuario;
            }
        }
        return null; // O lanzar una excepción de autenticación fallida
    }

    // Otros métodos de servicio para Usuario si los necesitas
}